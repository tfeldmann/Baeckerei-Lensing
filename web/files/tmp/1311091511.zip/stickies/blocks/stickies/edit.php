<?php 

	defined ('C5_EXECUTE') or die (_("Access Denied."));
	$bt -> inc('form_setup_html.php', array('c' => $c, 'b' => $b, 'controller' => $controller));
	
?>