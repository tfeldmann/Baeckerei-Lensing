<?php   defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<?php  
echo $this->controller->buildParentLink();
?>